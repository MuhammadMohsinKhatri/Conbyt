const SectionDivider = () => (
    <hr className="my-8 border-t border-surface/60 w-full" />
  );
  export default SectionDivider;